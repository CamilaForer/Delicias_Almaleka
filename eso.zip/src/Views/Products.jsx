import React from 'react'

export default function Products() {
  return (
    <div>Products</div>
  )
}
