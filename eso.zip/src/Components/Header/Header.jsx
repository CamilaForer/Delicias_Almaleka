import React from 'react'
import Logo from '../../img/Delicias Almaleka.png'

import {GiHamburgerMenu,GiShoppingCart} from "react-icons/gi";

export default function Header() {
  return (
    <header className="App-header">
        <GiHamburgerMenu className='icons'/>
        <img  className='logo' src={Logo}/>
        <GiShoppingCart className='icons'/>
      </header>
  )
}
