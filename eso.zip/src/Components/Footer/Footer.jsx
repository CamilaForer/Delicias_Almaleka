import React from 'react';
import {GrInstagram } from 'react-icons/Gr'


export default function Footer() {
  return (
    <Footer className='footer'>
      <GrInstagram/>
    </Footer>
  )
}
