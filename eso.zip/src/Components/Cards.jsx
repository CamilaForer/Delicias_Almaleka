import React from 'react'

export default function Cards() {
  return (
    <div>Cards</div>
  )
}
